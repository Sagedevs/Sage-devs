import React from 'react';

const Threads: React.FC = () => {
  return null; // Empty component since threads are now in layout
};

export default Threads;