import { createContext } from "react";

const SocketContext = createContext();

export default SocketContext;
